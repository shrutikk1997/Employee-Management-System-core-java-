package main;

import view.LoginFrame;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
LoginFrame f1=new LoginFrame();
	}

}
 